import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from '../decorators/roles.decorator';
import { Role } from '@prisma/client';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<Role[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!requiredRoles) return true;

    const { user } = context.switchToHttp().getRequest();

    const roleHierarchy: Record<Role, number> = {
      free: 0,
      premium: 1,
      admin: 2,
    };

    const userLevel = roleHierarchy[user.role as Role] ?? 0;
    const requiredLevel = Math.min(...requiredRoles.map((r) => roleHierarchy[r]));

    if (userLevel < requiredLevel) {
      throw new ForbiddenException('Bu işlem için yetkiniz yok.');
    }

    return true;
  }
}
